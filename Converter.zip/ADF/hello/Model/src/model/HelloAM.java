package model; 
import oracle.jbo.ApplicationModule; 
public interface HelloAM extends ApplicationModule { 
}