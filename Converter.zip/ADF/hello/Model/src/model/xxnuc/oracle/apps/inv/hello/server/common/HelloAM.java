package model.xxnuc.oracle.apps.inv.hello.server; 
import oracle.jbo.ApplicationModule; 
public interface HelloAM extends ApplicationModule { 
}