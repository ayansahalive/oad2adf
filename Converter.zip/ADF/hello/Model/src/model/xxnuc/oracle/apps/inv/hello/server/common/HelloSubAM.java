package model.xxnuc.oracle.apps.inv.hello.server.common;
import oracle.jbo.ApplicationModule;
 import oracle.jbo.server.ApplicationModuleImpl;
import java.util.Vector;import oracle.jbo.domain.Number;
public interface HelloSubAM extends ApplicationModule { 
/*** execute vo*/  void executeVOA1() ;
/*** execute vo*/  void executeVOA2() ;
/*** execute vo*/  void executeVOB() ;
// sample line comment
	 String testFunctionTobeAdded(String strX);
Vector vecMethod(Number numVal, Integer intX);
}