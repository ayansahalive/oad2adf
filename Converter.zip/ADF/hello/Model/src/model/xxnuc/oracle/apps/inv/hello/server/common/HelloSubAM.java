package model.xxnuc.oracle.apps.inv.hello.server; 
import oracle.jbo.ApplicationModule; 
public interface HelloSubAM extends ApplicationModule { 
/*** execute vo*/ public void executeVOA1();
/*** execute vo*/ public void executeVOA2();
/*** execute vo*/ public void executeVOB();
}