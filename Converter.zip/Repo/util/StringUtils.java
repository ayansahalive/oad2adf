package nl.amis.amislib.utils;

public class StringUtils {

    public static boolean isNullOrEmpty(String stringToEvaluate) {

        return stringToEvaluate == null || stringToEvaluate.isEmpty();
    }
}
