package nl.amis.amislib.utils;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

import oracle.adf.model.BindingContext;

import oracle.adf.model.DataControlFrame;
import oracle.adf.model.OperationParameter;
import oracle.adf.model.binding.DCDataControl;

import oracle.adf.model.binding.DCIteratorBinding;

import oracle.adf.model.binding.DCMethodParameterDef;

import oracle.binding.BindingContainer;
import oracle.binding.OperationBinding;

/**
 * A series of convenience functions for accessing operation bindings programmatically.
 *
 * $Id: OperationUtils.java
 */ 
public class OperationUtils {
    /**
     * Gets operation binding from pagedef
     * If operation binding doesn't exist, an exception is thrown
     * @param pBindingName: Name of the operation
     * @return
     */
    public static OperationBinding getOperationBinding(String pBindingName) {
        BindingContext bctx = BindingContext.getCurrent();
        BindingContainer bindings = bctx.getCurrentBindingsEntry();
        OperationBinding ob = bindings.getOperationBinding(pBindingName);
        if (ob == null) {
            throw new RuntimeException("Binding container has no '" + pBindingName + "' action binding");
        }
        return ob;
    }
    
    public static void createInsert (String pIteratorName) {
        DCIteratorBinding lIter = AmisUtils.findIterator(pIteratorName);
        lIter.getViewObject().createRow();
    }
    public static void delete (String pIteratorName) {
        DCIteratorBinding lIter = AmisUtils.findIterator(pIteratorName);
        lIter.removeCurrentRow();
    }
    public static void next (String pIteratorName) {
        DCIteratorBinding lIter = AmisUtils.findIterator(pIteratorName);
        lIter.getViewObject().next();
    }
    public static void previous (String pIteratorName) {
        DCIteratorBinding lIter = AmisUtils.findIterator(pIteratorName);
        lIter.getViewObject().previous();
    }    
    public static void first (String pIteratorName) {
        DCIteratorBinding lIter = AmisUtils.findIterator(pIteratorName);
        lIter.getViewObject().first();
    }    
    public static void last (String pIteratorName) {
        DCIteratorBinding lIter = AmisUtils.findIterator(pIteratorName);
        lIter.getViewObject().last();
    }    

    /**
     * Performs executeWithParams method on iterator with 1 long Value as parameter
     * @param pIteratorName: Name of the iterator
     * @param pParamName: Name of the parameter
     * @param pParamValue: Value of the parameter
     */
    public static void executeWithParams1Long (String pIteratorName, String pParamName, Long pParamValue) {
        OperationParameter lParam = new DCMethodParameterDef(pParamName, "java.lang.Long" , pParamValue);
        executeWithParams (pIteratorName, new OperationParameter[]{lParam});
    }
    public static void executeWithParams ( String pIteratorName, OperationParameter[] pParams )
    {
        DCIteratorBinding lIter = AmisUtils.findIterator(pIteratorName);
        Object[] lParamValues = new Object[]{};
        //DCMethodParameterDef(java.lang.String�name, java.lang.String�type, java.lang.Object�value)�// implements OperationParameter
        BindingContext bc = BindingContext.getCurrent();
        DataControlFrame dcf = bc.findDataControlFrame(bc.getCurrentDataControlFrame());
        Collection<DCDataControl> lDcCols = dcf.datacontrols();
        if (!lDcCols.isEmpty())
        {
            DCDataControl[] lDcColsA = lDcCols.toArray( new DCDataControl[0]);            
            lDcColsA[0].executeIteratorBindingWithParams(lIter, pParams, lParamValues);
        }
    }
    /**
     * Sets iterator on row defined by key
     * @param pOperationName, name of the operation
     * @param pParamName, name of the the parameter in the pagedef
     * @param pKeyValue, value of the key
     */
    public static void setCurrentRowWithKeyValue(String pOperationName, String pParamName, String pKeyValue) {
        OperationBinding ob = getOperationBinding(pOperationName);
        ob.getParamsMap().put(pParamName, pKeyValue);
        ob.execute();
    }

    /**
     * Sets iterator on row defined by key
     * Standard generated names for operation en parameter are used
     * worden gebruikt
     * @param pKeyValue
     */
    public static void setCurrentRowWithKeyValue(String pKeyValue) {
        OperationUtils.setCurrentRowWithKeyValue("setCurrentRowWithKeyValue", "rowKey", pKeyValue);
    }

    /**
     * Executes commit
     * @return
     */
    public static boolean commit() {
/*
        OperationBinding ob = getOperationBinding("Commit");
        ob.execute();

        if (ob.getErrors().size() == 0)
            return true;
        else
            return false;
*/
        boolean lErrors = false;
        BindingContext bc = BindingContext.getCurrent();
        DataControlFrame dcf = bc.findDataControlFrame(bc.getCurrentDataControlFrame());
        Collection<DCDataControl> dcCol = dcf.datacontrols();
        for (DCDataControl dCDataControl : dcCol) {
            if(dCDataControl.isTransactionDirty()) {
                try {
                    dCDataControl.commitTransaction();
                } catch (Exception e) {
                    lErrors = true;
                    FacesContext facesContext = FacesContext.getCurrentInstance();
                    facesContext.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, e.getMessage(), null));
                    e.printStackTrace();
                }
            }
        }
        return lErrors;
    }
    
    /**
     * Executes rollback operation
     * @return
     */
    public static boolean rollback() {
        /*
                OperationBinding ob = getOperationBinding("Rollback");
                ob.execute();

                if (ob.getErrors().size() == 0)
                    return true;
                else
                    return false;
        */        
        boolean lErrors = false;
        BindingContext bc = BindingContext.getCurrent();
        DataControlFrame dcf = bc.findDataControlFrame(bc.getCurrentDataControlFrame());
        Collection<DCDataControl> dcCol = dcf.datacontrols();
        for (DCDataControl dCDataControl : dcCol) {            
            if(dCDataControl.isTransactionDirty()) {
                try {
                    dCDataControl.rollbackTransaction();
                } catch (Exception e) {
                    lErrors = true;
                    FacesContext facesContext = FacesContext.getCurrentInstance();
                    facesContext.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, e.getMessage(), null));
                    e.printStackTrace();
                }
            }
        }
        return lErrors;
    }

    /**
     * Execute an operation in the pageDef
     * @param pOperationName : Name of de operation
     * @return Operationbinding containing result and Errors
     */
    public static OperationBinding doOperationWithErrors(String pOperationName) {
        return doOperationWithErrors(pOperationName, new HashMap ());
    }
    /**
     * Execute an operation in the pageDef
     * @param pOperationName : Name of de operation
     * @param pParamName: Parameter Name
     * @param pParamValue: Parameter Value
     * @return Operationbinding containing result and Errors
     */
    public static OperationBinding doOperationWithErrors(String pOperationName , String pParamName, Object pParamValue) {
        HashMap map = new HashMap();
        map.put (pParamName, pParamValue);
        return doOperationWithErrors(pOperationName, map);
    }

    /**
     * Execute an operation in the pageDef
     * @param pOperationName : Name of de operation
     * @param pParamsMap : parameters
     * @return Operationbinding containing result and Errors
     */
    public static OperationBinding doOperationWithErrors(String pOperationName, Map pParamsMap) {
        Object result = null;
        OperationBinding ob = getOperationBinding (pOperationName);
        Map lObMap = ob.getParamsMap();
        Set lKeySet = pParamsMap.keySet();
        //
        for (Object lKey : lKeySet) {
            lObMap.put(lKey, pParamsMap.get(lKey));
        }
        ob.execute();
        return ob;
    }

    /**
     * Executes operation in the pagedef file
     * @param pOperationName : name of the operation
     * @return bool indicating if errors are present
     */
    public static boolean doOperationHasErrors(String pOperationName) {
        return doOperationHasErrors (pOperationName, new HashMap());
    }
    /**
     * Executes operation in the pagedef file
     * @param pOperationName : name of the operation
     * @param pParamName: Parameter Name
     * @param pParamValue: Parameter Value
     * @return bool indicating if errors are present
     */
    public static boolean doOperationHasErrors(String pOperationName, String pParamName, Object pParamValue) {
        HashMap map = new HashMap();
        map.put (pParamName, pParamValue);
        return doOperationHasErrors (pOperationName, map);
    }

    /**
     * Executes operation in the pagedef file
     * @param pOperationName : name of the operation
     * @param pParamsMap : parameters
     * @return bool indicating if errors are present
     */
    public static boolean doOperationHasErrors(String pOperationName, Map pParamsMap) {
        Object result = null;
        OperationBinding ob = getOperationBinding (pOperationName);
        Map lObMap = ob.getParamsMap();
        Set lKeySet = pParamsMap.keySet();
        //
        for (Object lKey : lKeySet) {
            lObMap.put(lKey, pParamsMap.get(lKey));
        }
        ob.execute();
        if (ob.getErrors().size() == 0)
            return false;
        else
            return true;

    }

    /**
     * Execute operation pagedef file, Errors are not returned
     * @param pOperationName : Operation Name
     * @param pParamsMap : Parameters (Map)
     * @return Long  : result of the operation (Long)
     */
    public static Long doOperationReturnLong(String pOperationName, Map pParamsMap) {
        Long lResult = null;
        OperationBinding lOb = doOperationWithErrors(pOperationName, pParamsMap);
        Object o =  lOb.getResult();
        if (o != null)
        {
            lResult = Long.parseLong(o.toString());
        }
        return lResult;
    }
    /**
     * Execute operation pagedef file, Errors are not returned
     * @param pOperationName : Operation Name
     * @param pParamsMap : Parameters (Map)
     * @return Long  : result of the operation (String)
     */
    public static String doOperationReturnString(String pOperationName, Map pParamsMap) {
        String lResult = null;
        OperationBinding lOb = doOperationWithErrors(pOperationName, pParamsMap);
        Object o =  lOb.getResult();
        if (o != null)
        {
            lResult = o.toString();
        }
        return lResult;
    }

    /**
     * Execute operation pagedef file, Errors are not returned
     * @param pOperationName : Operation Name
     * @param pParamsMap : Parameters (Map)
     * @return Object  : result of the operation
     */
    public static Object doOperation(String pOperationName, Map pParamsMap) {

        OperationBinding lOb = doOperationWithErrors(pOperationName, pParamsMap);
        return lOb.getResult();
    }

    /**
     * Execute operation pagedef file with 1 parameter
     * @param pOperationName : Operation Name
     * @param pParamName: Parameter Name
     * @param pParamValue: Parameter Value
     * @return Object  : result of the operation
     */
    public static Object doOperation(String pOperationName, String pParamName, Object pParamValue) {
        HashMap map = new HashMap();
        map.put (pParamName, pParamValue);
        OperationBinding lOb = doOperationWithErrors(pOperationName, map);
        return lOb.getResult();
    }
    /**
     * Execute operation pagedef file with 1 parameter
     * @param pOperationName : Operation Name
     * @param pParamName: Parameter Name
     * @param pParamValue: Parameter Value
     * @return Long  : result of the operation (Long)
     */
    public static Long doOperationReturnLong(String pOperationName, String pParamName, Object pParamValue) {
        HashMap map = new HashMap();
        map.put (pParamName, pParamValue);
        return doOperationReturnLong (pOperationName, map);
    }    
    /**
     * Execute operation pagedef file with 1 parameter
     * @param pOperationName : Operation Name
     * @param pParamName: Parameter Name
     * @param pParamValue: Parameter Value
     * @return Long  : result of the operation (String)
     */
    public static String doOperationReturnString(String pOperationName, String pParamName, Object pParamValue) {
        HashMap map = new HashMap();
        map.put (pParamName, pParamValue);
        return doOperationReturnString (pOperationName, map);
    }    

    /**
     * Executes operation in pagedef file with no parameter
     * @param pOperationName
     * @return result (Object)
     */
    public static Object doOperation(String pOperationName) {
        return doOperation(pOperationName, new HashMap());
    }
    /**
     * Executes operation in pagedef file with no parameter
     * @param pOperationName
     * @return result (Long)
     */
    public static Long doOperationReturnLong(String pOperationName) {
        return doOperationReturnLong(pOperationName, new HashMap());
    }
    /**
     * Executes operation in pagedef file with no parameter
     * @param pOperationName
     * @return result (String)
     */
    public static String doOperationReturnString(String pOperationName) {
        return doOperationReturnString(pOperationName, new HashMap());
    }

}
