package nl.amis.amislib.utils;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;

import oracle.adf.view.rich.component.rich.RichPopup;
import oracle.adf.view.rich.component.rich.fragment.RichRegion;

import org.apache.myfaces.trinidad.render.ExtendedRenderKitService;
import org.apache.myfaces.trinidad.util.Service;


public class PopupUtils {
    /**
     * Closes popup programmatically
     * @param pRichPopup: the popup
     */
    public static void closePopup(RichPopup pRichPopup) {
        FacesContext fctx = FacesContext.getCurrentInstance();
        ExtendedRenderKitService service = Service.getRenderKitService(fctx, ExtendedRenderKitService.class);
        StringBuffer strbuffer = new StringBuffer();
        strbuffer.append("popup=AdfPage.PAGE.findComponent('");
        strbuffer.append(pRichPopup.getClientId(fctx));
        strbuffer.append("'); popup.hide();");
        service.addScript(fctx, strbuffer.toString());
    }

    /**
     * Closes popup programmatically
     * @param pPopupId: the popupId
     */
    public static void closePopup(String pPopupId) {
        RichPopup lPopup = (RichPopup) AmisUtils.findComponentInRoot(pPopupId);
        if (lPopup == null) {
            throw new RuntimeException("Popup " + pPopupId + " can not be found");
        } else {
            closePopup(lPopup);
        }
    }

    /**
     * Shows popup programmatically
     * @param pPopupId: the popupId
     */
    public static void showPopup(String pPopupId) {
        RichPopup lPopup = (RichPopup) AmisUtils.findComponentInRoot(pPopupId);
        if (lPopup == null) {
            throw new RuntimeException("Popup " + pPopupId + " can not be found");
        } else {
            showPopup(lPopup);
        }
    }

    /**
     * Shows popup programmatically
     * @param pRichPopup: the popup
     */
    public static void showPopup(RichPopup pRichPopup) {
        FacesContext fctx = FacesContext.getCurrentInstance();
        ExtendedRenderKitService service = Service.getRenderKitService(fctx, ExtendedRenderKitService.class);
        StringBuffer strbuffer = new StringBuffer();
        strbuffer.append("popup=AdfPage.PAGE.findComponent('");
        strbuffer.append(pRichPopup.getClientId(fctx));
        strbuffer.append("'); popup.show();");
        service.addScript(fctx, strbuffer.toString());
    }

    /**
     * Returns first popup surrounding a region
     * @param region
     * @return the Popup
     */
    public static RichPopup getParentPopup(RichRegion region) {
        boolean popupFound = false;
        UIComponent component = region.getParent();
        while (!popupFound && component != null) {
            if (component instanceof RichPopup) {
                popupFound = true;
                break;
            }
            component = component.getParent();
        }
        return (RichPopup) component;
    }

    /**
     * Closes the popup surrounding a region
     * @param pRegion
     */
    public static void closePopup(RichRegion pRegion) {
        RichPopup lPopup = PopupUtils.getParentPopup(pRegion);
        if (lPopup != null) {
            PopupUtils.closePopup(lPopup);
        }
    }
}
