package nl.amis.amislib.utils;

import java.io.IOException;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.el.ELContext;
import javax.el.ExpressionFactory;
import javax.el.MethodExpression;
import javax.el.ValueExpression;

import javax.faces.application.Application;
import javax.faces.application.FacesMessage;
import javax.faces.application.ViewHandler;
import javax.faces.component.UIComponent;
import javax.faces.component.UIViewRoot;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;

import oracle.adf.model.BindingContext;
import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCDataControl;
import oracle.adf.model.binding.DCIteratorBinding;
import oracle.adf.view.rich.context.AdfFacesContext;

import oracle.binding.BindingContainer;

import oracle.jbo.Row;
import oracle.jbo.uicli.binding.JUCtrlHierNodeBinding;

/**
 * A series of convenience functions for dealing with ADF Bindings.
 * Offers some extra functions on top of ADFUtils.java and JSFUtils.java
 *
 * $Id: AmisUtils.java
 */
public class AmisUtils {

    /**
     * Get FacesContext.
     * @return FacesContext
     */
    public static FacesContext getFacesContext() {
        return FacesContext.getCurrentInstance();
    }

    /**
     * Find an iterator binding in the current binding container by name.
     *
     * @param name iterator binding name
     * @return iterator binding
     */
    public static DCIteratorBinding findIterator(String name) {
        return ADFUtils.findIterator(name);
    }

    /**
     * Gets value of Id attribute in current row of pIteratorName
     * @param pIteratorName
     * @return
     */
    public static Long getIdByIterator(String pIteratorName) {
        return getLongValueByIterator(pIteratorName, "Id");
    }

    /**
     * Gets Long value of pAttributeName in current row of pIteratorName
     * @param pIteratorName
     * @param pAttributeName
     * @return
     */
    public static Long getLongValueByIterator(String pIteratorName, String pAttributeName) {
        Object lReturnValueO = getValueByIterator(pIteratorName, pAttributeName);
        Long lReturnValue = null;
        if (lReturnValueO != null) {
            lReturnValue = Long.parseLong(lReturnValueO.toString());
        }
        return lReturnValue;
    }

    /**
     * Gets String value of pAttributeName in current row of pIteratorName
     * @param pIteratorName
     * @param pAttributeName
     * @return
     */
    public static String getStringValueByIterator(String pIteratorName, String pAttributeName) {
        Object lReturnValueO = getValueByIterator(pIteratorName, pAttributeName);
        String lReturnValue = "";
        if (lReturnValueO != null) {
            lReturnValue = lReturnValueO.toString();
        }
        return lReturnValue;
    }

    /**
     * Gets current row in pIteratorName
     * @param pIteratorName
     * @return
     */
    public static Row getCurrentRow(String pIteratorName) {
        DCIteratorBinding lBinding = ADFUtils.findIterator(pIteratorName);
        if (lBinding == null) {
            throw new RuntimeException("Iterator " + pIteratorName + " can't be found.");
        }
        Row lRow = lBinding.getCurrentRow();
        if (lRow == null) {
            throw new RuntimeException("Iterator " + pIteratorName + " has no current row.");
        }
        return lRow;
    }

    /**
     * Set pValue of current Row in pIteratorName for pAttributeName
     * @param pIteratorName
     * @param pAttributeName
     * @param pValue
     */
    public static void setValueByIterator(String pIteratorName, String pAttributeName, Object pValue) {
        Row lRow = AmisUtils.getCurrentRow(pIteratorName);
        lRow.setAttribute(pAttributeName, pValue);
    }

    /**
     * Set value pValue in pAttributeName of Row pRow
     * @param pRow
     * @param pAttributeName
     * @param pValue
     */
    public static void setValueByRow(Row pRow, String pAttributeName, Object pValue) {
        pRow.setAttribute(pAttributeName, pValue);
    }

    /**
     * Bepaalt waarde van pAttributeName van huidige rij in iterator pIteratorName
     * @param pIteratorName
     * @param pAttributeName
     * @return
     */
    public static Object getValueByIterator(String pIteratorName, String pAttributeName) {
        DCIteratorBinding lBinding = ADFUtils.findIterator(pIteratorName);
        Row lRow = lBinding.getCurrentRow();
        Object lAttribute = null;
        if (lRow != null) {
            lAttribute = lRow.getAttribute(pAttributeName);
        }
        return lAttribute;
    }

    /**
     * Programmatic invocation of a method that an EL evaluates to.
     * The method must not take any parameters.
     *
     * @param el EL of the method to invoke
     * @return Object that the method returns
     */
    public static Object invokeEL(String el) {
        return invokeEL(el, new Class[0], new Object[0]);
    }

    /**
     * Programmatic invocation of a method that an EL evaluates to.
     *
     * @param el EL of the method to invoke
     * @param paramTypes Array of Class defining the types of the parameters
     * @param params Array of Object defining the values of the parametrs
     * @return Object that the method returns
     */
    public static Object invokeEL(String el, Class[] paramTypes, Object[] params) {
        FacesContext facesContext = FacesContext.getCurrentInstance();
        ELContext elContext = facesContext.getELContext();
        ExpressionFactory expressionFactory = facesContext.getApplication().getExpressionFactory();
        MethodExpression exp = expressionFactory.createMethodExpression(elContext, el, Object.class, paramTypes);

        return exp.invoke(elContext, params);
    }

    /**
     * Method to get the current row of a table from the el context.
     * More specifically: This method assumes an af:table with var="row" is being filled. It returns the row of the iterator that the
     * var of the af:table currently points to.
     *
     * @return Object that the method returns
     */
    public static Row getRowFromEl() {
        FacesContext fctx = FacesContext.getCurrentInstance();
        ELContext elctx = fctx.getELContext();
        ExpressionFactory efactory = fctx.getApplication().getExpressionFactory();
        ValueExpression ve = efactory.createValueExpression(elctx, "#{row}", Object.class);
        JUCtrlHierNodeBinding node = (JUCtrlHierNodeBinding) ve.getValue(elctx);
        return node.getRow();
    }

    public static Object evaluateEl(String el) {
        FacesContext fctx = FacesContext.getCurrentInstance();
        ELContext elctx = fctx.getELContext();
        ExpressionFactory efactory = fctx.getApplication().getExpressionFactory();
        ValueExpression ve = efactory.createValueExpression(elctx, el, Object.class);
        Object result = ve.getValue(elctx);
        return result;
    }


    /**
     * Convenience method for getting Pageflow variables.
     * @param key object key
     * @return pageflowscope object for key
     */
    public static Object getFromPageFlowScope(String key) {
        AdfFacesContext context = null;
        context = AdfFacesContext.getCurrentInstance();
        Map pageFlowState = context.getPageFlowScope();
        Object lReturnValue = pageFlowState.get(key);
        if (lReturnValue == null)
            throw new RuntimeException("Pageflowscope variable " + key + " does not exist!");
        return lReturnValue;
    }

    /**
     * Convenience method for getting Viewscope variables.
     * @param key object key
     * @return viewscope object for key
     */
    public static Object getFromViewScope(String key) {
        AdfFacesContext context = null;
        context = AdfFacesContext.getCurrentInstance();
        Map viewScopeState = context.getViewScope();
        Object lReturnValue = viewScopeState.get(key);
        if (lReturnValue == null)
            throw new RuntimeException("ViewScope variable " + key + " does not exist!");
        return lReturnValue;
    }

    /**
     * Refresh of UI Component
     * * @param pComponent
     */
    public static void refresh(UIComponent pComponent) {
        if (pComponent != null) {
            AdfFacesContext.getCurrentInstance().addPartialTarget(pComponent);
        }
    }

    /**
     * Refresh of UI Component
     * * @param pComponent (Component in a Object)
     */
    public static void refresh(Object pComponent) {
        if (pComponent != null && pComponent instanceof UIComponent) {
            UIComponent lComponent = (UIComponent) pComponent;
            AdfFacesContext.getCurrentInstance().addPartialTarget(lComponent);
        }
    }

    /**
     * Geeft de de waarde van een attribuut in de rij met index pIndex
     * in iterator pIteratorName
     * @param pIteratorName
     * @param pIndex
     * @param pAttributeName
     * @return
     */
    public static Long selectLongValueByIndex(String pIteratorName, Long pIndex, String pAttributeName) {
        Row lRow = selectRowByIndex(pIteratorName, pIndex);
        if (lRow != null) {
            Object lValueO = lRow.getAttribute(pAttributeName);
            if (lValueO == null) {
                return null;
            } else {
                return Long.parseLong(lValueO.toString());
            }
        } else {
            return null;
        }

    }

    /**
     * Geeft de de waarde van een attribuut in de rij met index pIndex
     * in iterator pIteratorName
     * @param pIteratorName
     * @param pIndex
     * @param pAttributeName
     * @return
     */
    public static String selectStringValueByIndex(String pIteratorName, Long pIndex, String pAttributeName) {
        Row lRow = selectRowByIndex(pIteratorName, pIndex);
        if (lRow != null) {
            Object lValueO = lRow.getAttribute(pAttributeName);
            if (lValueO == null) {
                return null;
            } else {
                return lValueO.toString();
            }
        } else {
            return null;
        }
    }

    /**
     * Geeft de rij met een bepaalde rij in een index
     * @param pIteratorName
     * @param pIndex
     * @return
     */
    public static Row selectRowByIndex(String pIteratorName, Long pIndex) {
        DCIteratorBinding lBinding = ADFUtils.findIterator(pIteratorName);
        Row lRow = null;
        try {
            lRow = lBinding.getAllRowsInRange()[pIndex.intValue()];
        } catch (ArrayIndexOutOfBoundsException e) {
            return null;
        } catch (NullPointerException e) {
            return null;
        }
        return lRow;
    }

    /**
     * Bepaalt de index in een iterator op basis van een attribuutnaam en attributt value
     * Voorbeeld geef mij uit de budgetteniterator de index van de rij met attributetName "Id" gelijk aan attributeValue 1234
     * @param pIteratorName
     * @param pAttributeName
     * @param pAttributeValue
     * @return -1 als niet gevonden, anders de index
     */
    public static int selectIndexByValue(String pIteratorName, String pAttributeName, String pAttributeValue) {
        DCIteratorBinding lBinding = ADFUtils.findIterator(pIteratorName);
        Row[] lRows = lBinding.getAllRowsInRange();

        boolean lRowFound = false;
        int max = lRows.length;

        int lIndex = -1;
        for (int i = 0; !lRowFound && i < max; i++) {
            String lValue = lRows[i].getAttribute(pAttributeName).toString();
            if (lValue.equals(pAttributeValue)) {
                lRowFound = true;
                lIndex = i;
            }
        }
        return lIndex;
    }

    public static void navigate(String pAction) {
        FacesContext context = FacesContext.getCurrentInstance();
        context.getApplication().getNavigationHandler().handleNavigation(context, null, pAction);
    }

    /**
     * Geeft een message van het met severity FacesMessage.Severity (bijv SEVERITY_ERROR)
     * @param messageText
     * @param severity
     * @return
     */

    public static void showMessage(String messageText, FacesMessage.Severity severity) {
        FacesMessage fm = new FacesMessage(messageText);
        fm.setSeverity(severity);
        FacesContext context = FacesContext.getCurrentInstance();
        context.addMessage(null, fm);
    }

    /**
     * Shows Error Message
     * @param messageText
     * @return
     */

    public static void showErrorMessage(String messageText) {
        showMessage(messageText, FacesMessage.SEVERITY_ERROR);
    }

    /**
     * Shows Info Message
     * @param messageText
     * @return
     */

    public static void showInfoMessage(String messageText) {
        showMessage(messageText, FacesMessage.SEVERITY_INFO);
    }

    /**
     * Shows Info Message
     * @param messageText
     * @return
     */

    public static void showWarning(String messageText) {
        showMessage(messageText, FacesMessage.SEVERITY_WARN);
    }

    /**
     * Method for taking a reference to a JSF binding expression and returning
     * the matching object (or creating it).
     * Throws exception when expression cannot be resolved
     * @param expression EL expression
     * @return Managed object
     */
    public static Object resolveExpression(String pExpression) {
        return resolveExpression(pExpression, false);
    }

    public static Object resolveExpression(String pExpression, Boolean pNullAllowed) {
        FacesContext facesContext = JSFUtils.getFacesContext();
        Application app = facesContext.getApplication();
        ExpressionFactory elFactory = app.getExpressionFactory();
        ELContext elContext = facesContext.getELContext();
        ValueExpression valueExp = elFactory.createValueExpression(elContext, pExpression, Object.class);
        Object lReturnObject = valueExp.getValue(elContext);
        if (!pNullAllowed) {
            if (lReturnObject == null)
                throw new RuntimeException("Expression " + pExpression + " resolves to null");
        }
        return lReturnObject;
    }

    public static String resolveExpressionAsString(String pExpression) {
        Object lObject = resolveExpression(pExpression);
        return lObject.toString();
    }

    public static String resolveExpressionAsString(String pExpression, Boolean pNullAllowed) {
        Object lObject = resolveExpression(pExpression, pNullAllowed);
        if (lObject != null)
            return lObject.toString();
        else
            return "";
    }

    public static Long resolveExpressionAsLong(String pExpression, Boolean pNullAllowed) {
        Object lObject = resolveExpression(pExpression, pNullAllowed);
        if (lObject != null)
            return Long.parseLong(lObject.toString());
        else
            return null;
    }

    public static Long resolveExpressionAsLong(String pExpression) {
        Object lObject = resolveExpression(pExpression);
        Long lReturnValue = Long.parseLong(lObject.toString());
        return lReturnValue;
    }

    public static Boolean resolveExpressionAsBoolean(String pExpression) {
        Object lObject = resolveExpression(pExpression);
        Boolean lReturnValue = Boolean.parseBoolean(lObject.toString());
        return lReturnValue;
    }


    /**
     * Convenience method for getting Session variables.
     * Throws exception when key is not found
     * @param key object key
     * @return session object for key
     */
    public static Object getFromSession(String key) {
        return getFromSession(key, true);
    }

    /**
     * Convenience method for setting Session variables.
     * @param key object key
     * @param object value to store
     */

    public static void storeOnSession(String key, Object object) {
        FacesContext ctx = getFacesContext();
        Map sessionState = ctx.getExternalContext().getSessionMap();
        sessionState.put(key, object);
    }

    /**
     * Convenience method for getting Session variables.
     * Throws exception when withError is true and key is not found
     * @param key object key
     * @param withError If this method should throw an error
     * @return session object for key
     */
    public static Object getFromSession(String key, boolean withError) {
        FacesContext ctx = JSFUtils.getFacesContext();
        Map sessionState = ctx.getExternalContext().getSessionMap();
        Object lReturnObject = sessionState.get(key);
        if (lReturnObject == null && withError)
            throw new RuntimeException("No Object with key " + key + " in session scope");
        return lReturnObject;
    }

    public static void refreshPage() {
        FacesContext fctx = FacesContext.getCurrentInstance();
        String refreshpage = fctx.getViewRoot().getViewId();
        ViewHandler ViewH = fctx.getApplication().getViewHandler();
        UIViewRoot UIV = ViewH.createView(fctx, refreshpage);
        UIV.setViewId(refreshpage);
        fctx.setViewRoot(UIV);
    }

    public static void refreshView() {
        FacesContext ctx = JSFUtils.getFacesContext();
        String viewId = ctx.getViewRoot().getViewId();
        String lRedirect = "faces" + viewId;
        try {
            ctx.getExternalContext().redirect(lRedirect);
        } catch (IOException e) {
            throw new RuntimeException("Interne fout, refresh van huidige pagina werkt niet redirect: " + lRedirect);
        }
    }

    /**
     * Locate an UIComponent from its root component.
     * Taken from http://www.jroller.com/page/mert?entry=how_to_find_a_uicomponent
     * @param base root Component (parent)
     * @param id UIComponent id
     * @return UIComponent object
     */
    public static UIComponent findComponent(UIComponent base, String id) {
        if (id.equals(base.getId()))
            return base;

        UIComponent children = null;
        UIComponent result = null;
        Iterator childrens = base.getFacetsAndChildren();
        while (childrens.hasNext() && (result == null)) {
            children = (UIComponent) childrens.next();
            if (id.equals(children.getId())) {
                result = children;
                break;
            }
            result = findComponent(children, id);
            if (result != null) {
                break;
            }
        }
        return result;
    }

    /**
     * Locate an UIComponent in view root with its component id. Use a recursive way to achieve this.
     * @param id UIComponent id
     * @return UIComponent object
     */
    public static UIComponent findComponentInRoot(String id) {
        UIComponent component = null;
        FacesContext facesContext = FacesContext.getCurrentInstance();
        if (facesContext != null) {
            UIComponent root = facesContext.getViewRoot();
            component = findComponent(root, id);
        }
        return component;
    }

    /**
     * Checks if datacontrol is dirty
     * @param pIteratorName
     */
    public static boolean isDirtyByIteratorName(String pIteratorName) {
        DCIteratorBinding lIterator = AmisUtils.findIterator(pIteratorName);
        return lIterator.getDataControl().isTransactionDirty();
    }

    /**
     * Get List of ADF Faces SelectItem for an iterator binding with description.
     *
     * Uses the value of the 'valueAttrName' attribute as the key for
     * the SelectItem key.
     *
     * @param iter ADF iterator binding
     * @param valueAttrName name of value attribute to use for key
     * @param displayAttrName name of the attribute from iterator rows to display
     * @param descriptionAttrName name of the attribute for description
     * @return ADF Faces SelectItem for an iterator binding with description
     */
    public static List<SelectItem> selectItemsForIterator(DCIteratorBinding iter, String valueAttrName,
                                                          String displayAttrName, String descriptionAttrName) {
        List<SelectItem> selectItems = new ArrayList<SelectItem>();
        for (Row r : iter.getAllRowsInRange()) {
            selectItems.add(new SelectItem(r.getAttribute(valueAttrName), (String) r.getAttribute(displayAttrName),
                                           (String) r.getAttribute(descriptionAttrName)));
        }
        return selectItems;
    }

    /**
     * Get List of ADF Faces SelectItem for an iterator binding.
     *
     * Uses the value of the 'valueAttrName' attribute as the key for
     * the SelectItem key.
     *
     * @param iter ADF iterator binding
     * @param valueAttrName name of value attribute to use for key
     * @param displayAttrName name of the attribute from iterator rows to display
     * @return ADF Faces SelectItem for an iterator binding
     */
    public static List<SelectItem> selectItemsForIterator(DCIteratorBinding iter, String valueAttrName,
                                                          String displayAttrName) {
        List<SelectItem> selectItems = new ArrayList<SelectItem>();
        for (Row r : iter.getAllRowsInRange()) {
            selectItems.add(new SelectItem(r.getAttribute(valueAttrName), (String) r.getAttribute(displayAttrName)));
        }
        return selectItems;
    }

    /**
     * Get List of attribute values for an iterator.
     * @param iteratorName ADF iterator binding name
     * @param valueAttrName value attribute to use
     * @return List of attribute values for an iterator
     */
    public static List attributeListForIterator(String iteratorName, String valueAttrName) {
        return attributeListForIterator(findIterator(iteratorName), valueAttrName);
    }

    /**
     * Get a List of attribute values for an iterator.
     *
     * @param iter iterator binding
     * @param valueAttrName name of value attribute to use
     * @return List of attribute values
     */
    public static List attributeListForIterator(DCIteratorBinding iter, String valueAttrName) {
        List attributeList = new ArrayList();
        for (Row r : iter.getAllRowsInRange()) {
            attributeList.add(r.getAttribute(valueAttrName));
        }
        return attributeList;
    }

    /**
     * Get List of ADF Faces SelectItem for an iterator binding.
     *
     * Uses the rowKey of each row as the SelectItem key.
     *
     * @param iteratorName ADF iterator binding name
     * @param displayAttrName name of the attribute from iterator rows to display
     * @return ADF Faces SelectItem for an iterator binding
     */
    public static List<SelectItem> selectItemsByKeyForIterator(String iteratorName, String displayAttrName) {
        return selectItemsByKeyForIterator(findIterator(iteratorName), displayAttrName);
    }

    /**
     * Get List of ADF Faces SelectItem for an iterator binding with description.
     *
     * Uses the rowKey of each row as the SelectItem key.
     *
     * @param iteratorName ADF iterator binding name
     * @param displayAttrName name of the attribute from iterator rows to display
     * @param descriptionAttrName name of the attribute for description
     * @return ADF Faces SelectItem for an iterator binding with description
     */
    public static List<SelectItem> selectItemsByKeyForIterator(String iteratorName, String displayAttrName,
                                                               String descriptionAttrName) {
        return selectItemsByKeyForIterator(findIterator(iteratorName), displayAttrName, descriptionAttrName);
    }

    /**
     * Get List of ADF Faces SelectItem for an iterator binding with description.
     *
     * Uses the rowKey of each row as the SelectItem key.
     *
     * @param iter ADF iterator binding
     * @param displayAttrName name of the attribute from iterator rows to display
     * @param descriptionAttrName name of the attribute for description
     * @return ADF Faces SelectItem for an iterator binding with description
     */
    public static List<SelectItem> selectItemsByKeyForIterator(DCIteratorBinding iter, String displayAttrName,
                                                               String descriptionAttrName) {
        List<SelectItem> selectItems = new ArrayList<SelectItem>();
        for (Row r : iter.getAllRowsInRange()) {
            selectItems.add(new SelectItem(r.getKey(), (String) r.getAttribute(displayAttrName),
                                           (String) r.getAttribute(descriptionAttrName)));
        }
        return selectItems;
    }

    /**
     * Get List of ADF Faces SelectItem for an iterator binding.
     *
     * Uses the rowKey of each row as the SelectItem key.
     *
     * @param iter ADF iterator binding
     * @param displayAttrName name of the attribute from iterator rows to display
     * @return List of ADF Faces SelectItem for an iterator binding
     */
    public static List<SelectItem> selectItemsByKeyForIterator(DCIteratorBinding iter, String displayAttrName) {
        List<SelectItem> selectItems = new ArrayList<SelectItem>();
        for (Row r : iter.getAllRowsInRange()) {
            selectItems.add(new SelectItem(r.getKey(), (String) r.getAttribute(displayAttrName)));
        }
        return selectItems;
    }

    /**
     * Return the current page's binding container.
     * @return the current page's binding container
     */
    public static BindingContainer getBindingContainer() {
        BindingContainer bindingContainer = BindingContext.getCurrent().getCurrentBindingsEntry();
        return bindingContainer;
        //return (BindingContainer)JSFUtils.resolveExpression("#{bindings}");
    }

    /**
     * Return the Binding Container as a DCBindingContainer.
     * @return current binding container as a DCBindingContainer
     */
    public static DCBindingContainer getDCBindingContainer() {
        return (DCBindingContainer) getBindingContainer();
    }

    /**
     * Find an DCDataControl in the current binding container by name.
     *
     * @param name iterator binding name
     * @return iterator binding
     */
    public static DCDataControl findDataControl(String name) {
        DCBindingContainer lBindingContainer = getDCBindingContainer();
        if (lBindingContainer == null) {
            throw new RuntimeException("Binding container not found");
        }
        DCDataControl dcDataControl = lBindingContainer.findDataControl(name);
        if (dcDataControl == null) {
            throw new RuntimeException("dcDataControl '" + name + "' not found");
        }
        return dcDataControl;
    }
}
