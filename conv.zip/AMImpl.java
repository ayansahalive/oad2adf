package conv;

import java.util.*;


public class AMImpl {
    public AMImpl() {
        super();
    }

    /**
     * Generate and write AMImpl file
     * @param path
     * @param app
     * @param dest
     */
    protected static void handleAMImpl(String path, String app, String dest, String src) throws Exception {
        System.out.println("Start Conv: handleAMImpl " + path + " " + app + " " + dest + " " + src);
        try {
            String name = path.substring(path.lastIndexOf(FileReaderWritter.getSeparator()) + 1);
            JavaCodeExtractor obj = new JavaCodeExtractor();
            Vector vec = obj.start(path);
            String str = "";

            // remove main
            for (int i = 0; i < vec.size(); i++) {
                String contents = vec.get(i) + "";
                if (contents.contains("void main"))
                    continue;
                str = str + "\n" + vec.get(i) + "";
            }

            // replace import
            str =
                str.replace("import oracle.apps.fnd.framework.server.OAApplicationModuleImpl;",
                            "import oracle.jbo.server.ApplicationModuleImpl;");

            // replace extends
            str = str.replace("OAApplicationModuleImpl", "ApplicationModuleImpl");

            // replace package
            String pkg = str.substring(0, str.indexOf(";")).trim(); // package xxnuc.oracle.apps.inv.hello.server;
            pkg = pkg.replace("package ", ""); // xxnuc.oracle.apps.inv.hello.server;
            str = str.replace(pkg, DirCreator.changedClassPath(pkg)); // model.xxnuc.oracle.apps.inv.hello.server;


            // replace imports of schema server an other sub directories under app
            String impVal = FileReaderWritter.getModelDestinationPath(path, app, dest, src);
            impVal =
                impVal.replace(dest + FileReaderWritter.getSeparator() + app + FileReaderWritter.getSeparator() +
                               "Model" + FileReaderWritter.getSeparator() + "src" + FileReaderWritter.getSeparator() +
                               "model" + FileReaderWritter.getSeparator(), "");
            impVal = impVal.substring(0, impVal.lastIndexOf(FileReaderWritter.getSeparator()));
            impVal = impVal.substring(0, impVal.lastIndexOf(FileReaderWritter.getSeparator())); // upto previous level
            impVal = impVal.replace(FileReaderWritter.getSeparator(), ".");
            str = str.replace("import " + impVal, "import model." + impVal);

            // replace Number
            str = str.replace(" Number", "oracle.jbo.domain.Number");

            // write a new file
            String destination = FileReaderWritter.getModelDestinationPath(path, app, dest, src);

            FileReaderWritter.writeFile(str, destination);

            System.out.println("End Conv: handleAMImpl");
        } catch (Exception e) {
            throw e;
        }

    }

    /**
     * handle def file
     * @param path
     * @param app
     * @param dest
     * @param src
     * @throws Exception
     */
    protected static void handleAMDefImpl(String path, String app, String dest, String src) throws Exception {
        System.out.println("Start Conv: handleAMDefImpl " + path + " " + app + " " + dest);

        try {
            String name = path.substring(path.lastIndexOf(FileReaderWritter.getSeparator()) + 1);
            JavaCodeExtractor obj = new JavaCodeExtractor();
            Vector vec = obj.start(path);
            String str = "";

            // remove main
            for (int i = 0; i < vec.size(); i++) {
                String contents = vec.get(i) + "";
                if (contents.contains("void main"))
                    continue;
                str = str + "\n" + vec.get(i) + "";
            }

            // replace package
            String pkg = str.substring(0, str.indexOf(";")).trim();
            pkg = pkg.replace("package ", "");
            str = str.replace(pkg, DirCreator.changedClassPath(pkg));

            // write a new file
            String destination = FileReaderWritter.getModelDestinationPath(path, app, dest, src);

            FileReaderWritter.writeFile(str, destination);

            System.out.println("End Conv: handleAMDefImpl");
        } catch (Exception e) {
            throw e;
        }
    }
}
