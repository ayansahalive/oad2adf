package conv;

import java.util.*;


public class AMImpl {
    public AMImpl() {
        super();
    }

    /**
     * Generate and write AMImpl file
     * @param path
     * @param app
     * @param dest
     */
    protected static void handleAMImpl(String path, String app, String dest, String src) throws Exception {
        System.out.println("Start Conv: handleAMImpl " + path + " " + app + " " + dest + " " + src);
        try {
            String name = path.substring(path.lastIndexOf(FileReaderWritter.getSeparator()) + 1);
            JavaCodeExtractor obj = new JavaCodeExtractor();
            Vector vec = obj.start(path);
            String str = "";

            // remove main
            for (int i = 0; i < vec.size(); i++) {
                String contents = vec.get(i) + "";
                if (contents.contains("void main"))
                    continue;
                str = str + "\n" + vec.get(i) + "";
            }

            // replace import
            str =
                str.replace("import oracle.apps.fnd.framework.server.OAApplicationModuleImpl;",
                            "import oracle.jbo.server.ApplicationModuleImpl;");

            // replace extends
            str = str.replace("OAApplicationModuleImpl", "ApplicationModuleImpl");

            // replace package
            String pkg = str.substring(0, str.indexOf(";")).trim(); // package xxnuc.oracle.apps.inv.hello.server;
            pkg = pkg.replace("package ", ""); // xxnuc.oracle.apps.inv.hello.server;
            str = str.replace(pkg, DirCreator.changedClassPath(pkg)); // model.xxnuc.oracle.apps.inv.hello.server;


            // replace imports of schema server an other sub directories under app
            String impVal = FileReaderWritter.getModelDestinationPath(path, app, dest, src);
            impVal =
                impVal.replace(dest + FileReaderWritter.getSeparator() + app + FileReaderWritter.getSeparator() +
                               "Model" + FileReaderWritter.getSeparator() + "src" + FileReaderWritter.getSeparator() +
                               "model" + FileReaderWritter.getSeparator(), "");
            impVal = impVal.substring(0, impVal.lastIndexOf(FileReaderWritter.getSeparator()));
            impVal = impVal.substring(0, impVal.lastIndexOf(FileReaderWritter.getSeparator())); // upto previous level
            impVal = impVal.replace(FileReaderWritter.getSeparator(), ".");
            System.out.println("********************************************** pkgVal" + impVal);
            str = str.replace("import " + impVal, "import model." + impVal);

            // replace Number
            str = str.replace(" Number", "oracle.jbo.domain.Number");

            // write a new file
            String destination = FileReaderWritter.getModelDestinationPath(path, app, dest, src);

            FileReaderWritter.writeFile(str, destination);

            generateInterface(path, app, dest, src);

            System.out.println("End Conv: handleAMImpl");
        } catch (Exception e) {
            throw e;
        }

    }

    /**
     * handle def file
     * @param path
     * @param app
     * @param dest
     * @param src
     * @throws Exception
     */
    protected static void handleAMDefImpl(String path, String app, String dest, String src) throws Exception {
        System.out.println("Start Conv: handleAMDefImpl " + path + " " + app + " " + dest);

        try {
            String name = path.substring(path.lastIndexOf(FileReaderWritter.getSeparator()) + 1);
            JavaCodeExtractor obj = new JavaCodeExtractor();
            Vector vec = obj.start(path);
            String str = "";

            // remove main
            for (int i = 0; i < vec.size(); i++) {
                String contents = vec.get(i) + "";
                if (contents.contains("void main"))
                    continue;
                str = str + "\n" + vec.get(i) + "";
            }

            // replace package
            String pkg = str.substring(0, str.indexOf(";")).trim();
            pkg = pkg.replace("package ", "");
            str = str.replace(pkg, DirCreator.changedClassPath(pkg));

            // write a new file
            String destination = FileReaderWritter.getModelDestinationPath(path, app, dest, src);

            FileReaderWritter.writeFile(str, destination);

            System.out.println("End Conv: handleAMDefImpl");
        } catch (Exception e) {
            throw e;
        }
    }

    /**
     * generate interface file for bindings access in VC
     * @param path
     * @param app
     * @param dest
     * @param src
     * @throws Exception
     */
    protected static void generateInterface(String path, String app, String dest, String src) throws Exception {
        System.out.println("Start Conv: generateInterface " + path + " " + app + " " + dest);

        String name = path.substring(path.lastIndexOf(FileReaderWritter.getSeparator()) + 1);
        String amName = name.replace(".java", "");
        amName = amName.replace("Impl", "");

        JavaCodeExtractor obj = new JavaCodeExtractor();
        Vector vec = obj.start(path);

        Vector intfc = new Vector();

        for (int i = 0; i < vec.size(); i++) {
            String str = vec.get(i) + "";

            int startBraces = str.indexOf("{");
            int semicolon = str.indexOf(";");

            if (startBraces == -1 && semicolon != -1)
                startBraces = semicolon + 1;
            else if (semicolon == -1 && startBraces != -1)
                semicolon = startBraces + 1;

            if (semicolon > startBraces && !str.contains("constructor") && !str.contains("void main")) {
                startBraces = str.indexOf("{");
                String methodHeader = str.subSequence(0, startBraces - 1) + ";";
                if (!methodHeader.contains("get") && !methodHeader.contains("set"))
                    intfc.addElement(methodHeader);
            }
        }


        // logic to get package
        String pkgVal = FileReaderWritter.getModelDestinationPath(path, app, dest, src);
        pkgVal =
            pkgVal.replace(dest + FileReaderWritter.getSeparator() + app + FileReaderWritter.getSeparator() + "Model" +
                           FileReaderWritter.getSeparator() + "src" + FileReaderWritter.getSeparator() + "model" +
                           FileReaderWritter.getSeparator(), "");
        pkgVal = pkgVal.substring(0, pkgVal.lastIndexOf(FileReaderWritter.getSeparator()));
        pkgVal = pkgVal.replace(FileReaderWritter.getSeparator(), ".");
        pkgVal = "model." + pkgVal;


        String contents = "package " + pkgVal + "; \n";
        contents += "import oracle.jbo.ApplicationModule; \n";
        contents += "public interface " + amName + " extends ApplicationModule { \n";

        for (int i = 0; i < intfc.size(); i++) {
            contents += intfc.get(i) + "\n";
        }

        contents += "}";

        // write a new file
        String destination = FileReaderWritter.getModelDestinationPath(path, app, dest, src);
        String x = destination.substring(0, destination.lastIndexOf(FileReaderWritter.getSeparator()));
        x = x + FileReaderWritter.getSeparator() + "common" + FileReaderWritter.getSeparator() + amName + ".java";


        FileReaderWritter.writeFile(contents, x);

        System.out.println("End Conv: generateInterface");
    }
}
