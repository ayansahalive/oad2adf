package conv;

import java.io.*;

import javax.xml.transform.*;
import javax.xml.transform.dom.*;
import javax.xml.transform.stream.*;

import org.w3c.dom.*;


public class FileReaderWritter {
    public FileReaderWritter() {
        super();
    }

    /**
     * Write contenets of a file to a directory
     * @param contents
     * @param path
     */
    protected static void writeFile(String contents, String path) throws Exception {
        System.out.println("Start Conv: writeFile " + path);
        try {
            if (null != contents && !"".equals(contents) && !"null".equals(contents)) {
                FileOutputStream outputStream = new FileOutputStream(path);
                byte[] strToBytes = contents.getBytes();
                outputStream.write(strToBytes);
                outputStream.close();
            }
            System.out.println("End Conv: writeFile");
        } catch (Exception e) {
            throw e;
        }
    }

    /**
     * copy file from source to destination
     * @param src
     * @param dest
     */
    protected static void copyFile(String src, String dest) throws Exception {
        System.out.println("Start Conv: copyFile " + src + " " + dest);
        try {
            InputStream is = null;
            OutputStream os = null;
            try {
                is = new FileInputStream(src);
                os = new FileOutputStream(dest);
                byte[] buffer = new byte[1024];
                int length;
                while ((length = is.read(buffer)) > 0) {
                    os.write(buffer, 0, length);
                }
            } finally {
                is.close();
                os.close();
            }
            System.out.println("End Conv: copyFile");
        } catch (Exception e) {
            throw e;
        }
    }

    /**
     * return character contents of a file
     * @param path
     * @return
     */
    /* protected static String getCharContents(String path) throws Exception {
        System.out.println("Start Conv: getCharContents " + path);
        String strTemp = "";
        try {
            BufferedReader rd = new BufferedReader(new InputStreamReader(new FileInputStream(path)));
            CharBuffer chbuff = CharBuffer.allocate(96);
            while (rd.read(chbuff) > 0) {
                chbuff.flip();
                while (chbuff.hasRemaining()) {
                    char ch = chbuff.get();
                    strTemp = strTemp + ch;
                }
                chbuff.clear();
            }
            rd.close();
            System.out.println("End Conv: getCharContents");
        } catch (Exception e) {
            throw e;
        }
        return strTemp;
    } */
    protected static String getCharContents(String path) throws Exception {
        BufferedReader reader;
        String ret = "";
        try {
            reader = new BufferedReader(new FileReader(path));
            String line = reader.readLine();
            while (line != null) {
                ret = ret + line + "\n";
                line = reader.readLine();
            }
            reader.close();
            return ret;
        } catch (Exception e) {
            throw e;
        }
    }

    /**
     * finalizer and generate a modified XML file
     * @param doc
     * @param Dest
     */
    protected static void writeXMLFile(Document doc, String Dest) throws Exception {
        System.out.println("Start Conv: writeXMLFile " + Dest);
        try {
            Transformer transformer = TransformerFactory.newInstance().newTransformer();
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            DocumentType doctype = doc.getDoctype();
            if (null != doctype && null != doctype.getSystemId())
                transformer.setOutputProperty(OutputKeys.DOCTYPE_SYSTEM, doctype.getSystemId());
            Source source = new DOMSource(doc);
            Result result = new StreamResult(new File(Dest));
            transformer.transform(source, result);

            System.out.println("End Conv: writeXMLFile");
        } catch (Exception e) {
            throw e;
        }
    }

    /**
     * append contents to a text file
     * @param content
     * @param filePath
     * @throws Exception
     */
    protected static void appendFile(String contents, String path) throws Exception {
        System.out.println("Start Conv: appendModelBundle " + contents + " " + path);
        try {
            FileWriter fw = null;
            fw = new FileWriter(path, true);
            if (null == fw)
                writeFile(contents, path);
            BufferedWriter bw = new BufferedWriter(fw);
            bw.write(contents);
            bw.newLine();
            bw.close();
            fw.close();
            System.out.println("End Conv: appendModelBundle ");
        } catch (Exception e) {
            throw e;
        }
    }

    /**
     * convert attributes to initcaps
     * @param param
     * @return
     */
    public static String toInitCap(String param) {
        System.out.println("Start Conv: toInitCap " + param);
        if (param != null && param.length() > 0) {
            param = param.toLowerCase();
            char[] array = param.toCharArray();
            array[0] = Character.toUpperCase(array[0]);
            return new String(array);
        } else {
            System.out.println("End Conv: toInitCap ");
            return "";
        }
    }

    /**
     * get OS file separator
     * @return
     */
    protected static String getSeparator() {
        String separator = "/";
        String os = System.getProperty("os.name");
        if (os.contains("Windows") || os.contains("windows"))
            separator = "\\";
        return separator;
    }
}
