package conv;


public class Class1 {
    public Class1() {
        super();
    }

    public static void main(String[] args) {
        String dest = "D:\\Converter\\ADF\\hello\\Model\\src\\model\\server\\HelloAM.xml";
        String x = dest.substring(0, dest.lastIndexOf(FileReaderWritter.getSeparator()));
        System.out.println(x);
    }

    protected static String getSeparator() {
        String separator = "/";
        String os = System.getProperty("os.name");
        if (os.contains("Windows") || os.contains("windows"))
            separator = "\\";
        return separator;
    }
}
