package conv;

import java.io.*;

import javax.xml.parsers.*;

import org.w3c.dom.*;


public class VOXml {
    public VOXml() {
        super();
    }

    /**
     * generate VOXml
     * @param path
     * @param app
     * @param dest
     * @param repo
     * @throws Exception
     */
    protected static void handleVOXml(String path, String app, String dest, String repo, String src) throws Exception {
        System.out.println("Start Conv: handleVOXml " + path + " " + app + " " + dest + " " + repo);

        String name = path.substring(path.lastIndexOf(FileReaderWritter.getSeparator()) + 1);
        String voName = name.replace(".xml", "");
        String topApp = dest + FileReaderWritter.getSeparator() + app;
        String pathModel = topApp + FileReaderWritter.getSeparator() + "Model";
        String pathModelsrc =
            pathModel + FileReaderWritter.getSeparator() + "src" + FileReaderWritter.getSeparator() + "model";

        String destination = FileReaderWritter.getModelDestinationPath(path, app, dest, src);

        createVOXml(destination, repo);

        File oafVO = new File(path); // OAF
        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        dbFactory.setValidating(false);
        DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
        Document oafDoc = dBuilder.parse(oafVO);
        Element ViewObjectOAf = oafDoc.getDocumentElement();

        File adfVO = new File(destination);
        DocumentBuilderFactory newDbFactory = DocumentBuilderFactory.newInstance();
        newDbFactory.setValidating(false);
        DocumentBuilder newDBuilder = newDbFactory.newDocumentBuilder();
        Document adfDoc = newDBuilder.parse(adfVO);
        Element ViewObjectAdf = adfDoc.getDocumentElement();

        // update ViewObject attributes for classes
        NamedNodeMap attrs = ViewObjectOAf.getAttributes();
        for (int i = 0; i < attrs.getLength(); i++) {
            Node currentAtt = attrs.item(i);
            if (currentAtt.getNodeName().equals("ComponentClass") || currentAtt.getNodeName().equals("DefClass")) {
                String val = DirCreator.changedClassPath(currentAtt.getNodeValue());
                ViewObjectAdf.setAttribute(currentAtt.getNodeName(), val);
            } else if (currentAtt.getNodeName().equals("Name"))
                ViewObjectAdf.setAttribute(currentAtt.getNodeName(), currentAtt.getNodeValue());
            // new code
            else if (currentAtt.getNodeName().equals("RowClass")) {
                String val = currentAtt.getNodeValue();
                if (val.equals("oracle.apps.fnd.framework.server.OAViewRowImpl")) {
                    // for entity VO
                    val = "oracle.jbo.server.ViewRowImpl";
                } else {
                    val = DirCreator.changedClassPath(currentAtt.getNodeValue());
                }
                ViewObjectAdf.setAttribute(currentAtt.getNodeName(), val);
            }
            // end of new code
        }

        // query and attributes
        NodeList nodesOaf = ViewObjectOAf.getChildNodes();
        for (int i = 0; i < nodesOaf.getLength(); i++) {
            Node currentNode = nodesOaf.item(i);
            if (currentNode.getNodeType() == Node.ELEMENT_NODE) {
                if (currentNode.getNodeName().equals("SQLQuery")) {
                    Node newNode = adfDoc.importNode(currentNode, true);
                    ViewObjectAdf.appendChild(newNode);
                } else if (currentNode.getNodeName().equals("ViewAttribute")) {
                    Node newNode = adfDoc.importNode(currentNode, true);
                    NamedNodeMap newAttrs = newNode.getAttributes();
                    for (int j = 0; j < newAttrs.getLength(); j++) {
                        Node subNode = newAttrs.item(i);
                        if (null != subNode && subNode.getNodeType() == Node.ELEMENT_NODE)
                            newNode.removeChild(subNode); // DesignTime
                    }
                    ViewObjectAdf.appendChild(newNode);
                } else if (currentNode.getNodeName().equals("EntityUsage")) {
                    Node newNode = adfDoc.importNode(currentNode, true);

                    Element x = (Element) newNode;
                    NamedNodeMap attrEnt = x.getAttributes();
                    for (int j = 0; j < attrEnt.getLength(); j++) {
                        Attr currentAtt = (Attr) attrEnt.item(j);
                        String strAttr = currentAtt.getName();
                        if (strAttr.equals("Entity")) {
                            String val = currentAtt.getValue();
                            val = DirCreator.changedClassPath(val);
                            currentAtt.setValue(val);
                        }
                    }
                    NodeList designList = newNode.getChildNodes();
                    for (int l = 0; l < designList.getLength(); l++) {
                        Node design = designList.item(l);
                        if (design.getNodeType() == Node.ELEMENT_NODE && design.getNodeName().equals("DesignTime")) {
                            newNode.removeChild(design); // remove design
                        }
                    }


                    ViewObjectAdf.appendChild(newNode);
                }
            }
        }

        // label bundle properties
        Node Properties = adfDoc.createElement("Properties");
        Node SchemaBasedProperties = adfDoc.createElement("SchemaBasedProperties");
        Element LABEL = adfDoc.createElement("LABEL");

        String impVal = FileReaderWritter.getModelDestinationPath(path, app, dest, src);
        impVal =
            impVal.replace(dest + FileReaderWritter.getSeparator() + app + FileReaderWritter.getSeparator() + "Model" +
                           FileReaderWritter.getSeparator() + "src" + FileReaderWritter.getSeparator() + "model" +
                           FileReaderWritter.getSeparator(), "");
        impVal = impVal.substring(0, impVal.lastIndexOf(FileReaderWritter.getSeparator()));
        impVal = impVal.replace(FileReaderWritter.getSeparator(), ".");
        impVal = "model." + impVal + ".";

        LABEL.setAttribute("ResId", impVal + voName + "_LABEL");
        String contents = impVal + voName + "_LABEL=" + voName;
        FileReaderWritter.appendFile(contents,
                                     pathModelsrc + FileReaderWritter.getSeparator() + "ModelBundle.properties");
        SchemaBasedProperties.appendChild(LABEL);
        Properties.appendChild(SchemaBasedProperties);
        ViewObjectAdf.appendChild(Properties);

        // jpx
        JPXGen.checkContainee(impVal.substring(0, impVal.lastIndexOf(".")), pathModelsrc);

        // write files
        FileReaderWritter.writeXMLFile(adfDoc, destination);

        System.out.println("End Conv: handleVOXml ");
    }

    /**
     * generate initial file
     * @param dest
     * @param repo
     * @param src
     * @throws Exception
     */
    private static void createVOXml(String dest, String repo) throws Exception {
        System.out.println("Start Conv: createVOXml " + dest + " " + repo);
        String contents =
            "<?xml version=\"1.0\" encoding=\"UTF-8\" ?>\n" + "<!DOCTYPE ViewObject SYSTEM \"jbo_03_01.dtd\">" + "" +
            "<ViewObject" + "  xmlns=\"http://xmlns.oracle.com/bc4j\"" + "  Version=\"12.1.3.10.47\"" +
            "  InheritPersonalization=\"merge\"" + "  BindingStyle=\"OracleName\"" + "  CustomQuery=\"true\"" +
            "  PageIterMode=\"Full\">" + "  " + "  <DesignTime>" +
            "    <Attr Name=\"_codeGenFlag2\" Value=\"Access|Def|Coll|Prog|VarAccess\"/>" +
            "    <Attr Name=\"_isExpertMode\" Value=\"true\"/>" + "    <Attr Name=\"_isCodegen\" Value=\"true\"/>" +
            "  </DesignTime>" + "  <ResourceBundle>\n" + "    <PropertiesBundle\n" +
            "      PropertiesFile=\"model.ModelBundle\"/>\n" + "  </ResourceBundle>\n" + "</ViewObject>";

        DirCreator.copyADFDTD(repo, dest);
        FileReaderWritter.writeFile(contents, dest);
        System.out.println("End Conv: createVOXml ");
    }
}
