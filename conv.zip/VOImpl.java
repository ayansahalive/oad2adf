package conv;

import java.util.*;


public class VOImpl {
    public VOImpl() {
        super();
    }

    /**
     * convert vo impl
     * @param path
     * @param app
     * @param dest
     * @throws Exception
     */
    protected static void handleVOImpl(String path, String app, String dest, String src) throws Exception {
        System.out.println("Start Conv: handleVOImpl " + path + " " + app + " " + dest);

        String name = path.substring(path.lastIndexOf(FileReaderWritter.getSeparator()) + 1);
        JavaCodeExtractor obj = new JavaCodeExtractor();
        Vector vec = obj.start(path);
        String str = "";


        for (int i = 0; i < vec.size(); i++) {
            str = str + "\n" + vec.get(i) + "";
        }

        if (null != str && !"".equals(str) &&
            !"null".equals(str)) {
            // replace import
            str =
                str.replace("import oracle.apps.fnd.framework.server.OAViewObjectImpl;",
                            "import oracle.jbo.server.ViewObjectImpl; import oracle.jbo.server.ViewRowSetImpl; import oracle.jbo.Row;");

            // replace extends
            str = str.replace("OAViewObjectImpl", "ViewObjectImpl");

            // replace package
            String pkg = str.substring(0, str.indexOf(";")).trim();
            pkg = pkg.replace("package ", "");
            str = str.replace(pkg, DirCreator.changedClassPath(pkg));


            // datasourceOverride option selected
            if (str.contains("getEstimatedRowCount")) {

                String optional_code =
                    "    /**" + "     * getQueryHitCount - overridden for custom java data source support." +
                    "     */" + "    @Override" + "    public long getQueryHitCount(ViewRowSetImpl viewRowSet) {" +
                    "        long value = super.getQueryHitCount(viewRowSet);" + "        return value;" + "    }" +
                    "" + "    /**" + "     * getCappedQueryHitCount - overridden for custom java data source support." +
                    "     */" + "    @Override" +
                    "    public long getCappedQueryHitCount(ViewRowSetImpl viewRowSet, Row[] masterRows, long oldCap, long cap) {" +
                    "        long value = super.getCappedQueryHitCount(viewRowSet, masterRows, oldCap, cap);" +
                    "        return value;" + "    }";

                int lastBrace = str.lastIndexOf("}");
                String temp = "";
                temp = str.substring(0, lastBrace) + optional_code + str.substring(lastBrace);
                str = temp;
            }


            // write a new file
            String destination = FileReaderWritter.getModelDestinationPath(path, app, dest, src);

            FileReaderWritter.writeFile(str, destination);
        }

        System.out.println("End Conv: handleVOImpl ");
    }

    /**
     * convert vo Row
     * @param path
     * @param app
     * @param dest
     * @throws Exception
     */
    protected static void handleVORowImpl(String path, String app, String dest, String src) throws Exception {
        System.out.println("Start Conv: handleVORowImpl " + path + " " + app + " " + dest);

        String name = path.substring(path.lastIndexOf(FileReaderWritter.getSeparator()) + 1);
        JavaCodeExtractor obj = new JavaCodeExtractor();
        Vector vec = obj.start(path);
        String str = "";

        Vector attrVec = new Vector();

        // remove accessor
        for (int i = 0; i < vec.size(); i++) {
            String contents = vec.get(i) + "";
            if (contents.contains("setAttrInvokeAccessor") || contents.contains("getAttrInvokeAccessor")) {
                continue;
            } else if (contents.contains("public static final int")) {
                String attr =
                    contents.subSequence(contents.indexOf("int") + 3, contents.indexOf("=")).toString().trim();
                attr = FileReaderWritter.toInitCap(attr);
                String temp =
                    (contents.substring(0, contents.indexOf("=")) + " = AttributesEnum." + attr + ".index();").trim();
                vec.set(i, temp);
                attrVec.addElement(attr);
            }
            str = str + "\n" + vec.get(i) + "";
        }

        if (null != str && !"".equals(str) && !"null".equals(str)) {
            // replace import
            str = str.replace("import oracle.jbo.domain.Number;", "");
            str =
                str.replace("import oracle.apps.fnd.framework.server.OAViewRowImpl;",
                            "import oracle.jbo.server.ViewRowImpl;");

            // replace extends
            str = str.replace("OAViewRowImpl", "ViewRowImpl");

            // replace package
            String pkg = str.substring(0, str.indexOf(";")).trim();
            pkg = pkg.replace("package ", "");
            str = str.replace(pkg, DirCreator.changedClassPath(pkg));

        }

        String accessor = generateEnumeration(attrVec);
        str = str.substring(0, str.lastIndexOf("}")) + accessor + "}";

        str = str.replace("Number", "oracle.jbo.domain.Number");

        // write a new file
        String destination = FileReaderWritter.getModelDestinationPath(path, app, dest, src);

        FileReaderWritter.writeFile(str, destination);

        System.out.println("End Conv: handleVORowImpl ");
    }

    /**
     * convert VO def
     * @param path
     * @param app
     * @param dest
     * @throws Exception
     */
    protected static void handleVODef(String path, String app, String dest, String src) throws Exception {
        System.out.println("Start Conv: handleVODef " + path + " " + app + " " + dest);

        String name = path.substring(path.lastIndexOf(FileReaderWritter.getSeparator()) + 1);
        JavaCodeExtractor obj = new JavaCodeExtractor();
        Vector vec = obj.start(path);
        String str = "";

        for (int i = 0; i < vec.size(); i++) {
            str = str + "\n" + vec.get(i) + "";
        }

        // replace package
        String pkg = str.substring(0, str.indexOf(";")).trim();
        pkg = pkg.replace("package ", "");
        str = str.replace(pkg, DirCreator.changedClassPath(pkg));


        // write a new file
        String destination = FileReaderWritter.getModelDestinationPath(path, app, dest, src);

        FileReaderWritter.writeFile(str, destination);

        System.out.println("End Conv: handleVODef ");
    }

    /**
     * handle vo client class
     * @param path
     * @param app
     * @param dest
     * @param src
     * @throws Exception
     */
    protected static void handleVOClient(String path, String app, String dest, String src) throws Exception {
        System.out.println("Start Conv: handleVODef " + path + " " + app + " " + dest);

        String name = path.substring(path.lastIndexOf(FileReaderWritter.getSeparator()) + 1);
        JavaCodeExtractor obj = new JavaCodeExtractor();
        Vector vec = obj.start(path);
        String str = "";

        for (int i = 0; i < vec.size(); i++) {
            str = str + "\n" + vec.get(i) + "";
        }

        // replace package
        String pkg = str.substring(0, str.indexOf(";")).trim();
        pkg = pkg.replace("package ", "");
        str = str.replace(pkg, DirCreator.changedClassPath(pkg));
        //replace import reference for client
        // ********************************************************* NEED TO CODE


        // write a new file
        String destination = FileReaderWritter.getModelDestinationPath(path, app, dest, src);

        FileReaderWritter.writeFile(str, destination);

        System.out.println("End Conv: handleVODef ");
    }

    /**
     * generate enumeration for row indices
     * @param attrVec
     * @return
     */
    private static String generateEnumeration(Vector attrVec) {
        System.out.println("Start Conv: generateEnumeration ");
        String strHead = "public enum AttributesEnum {";

        String strBody = "";
        int size = attrVec.size();
        for (int i = 0; i < size; i++) {
            String contents = attrVec.get(i) + "";
            if (i == size - 1)
                strBody = strBody + "\n" + contents + ";";
            else if (i < size)
                strBody = strBody + "\n" + contents + ",";
        }

        String strTail =
            " private static AttributesEnum[] vals = null; private static final int firstIndex = 0; public int index() {" +
            " return AttributesEnum.firstIndex() + ordinal(); } public static final int firstIndex() { return firstIndex; } public static int count() {" +
            " return AttributesEnum.firstIndex() + AttributesEnum.staticValues().length; } public static final AttributesEnum[] staticValues() {" +
            " if (vals == null) { vals = AttributesEnum.values(); } return vals; }}";

        System.out.println("End Conv: generateEnumeration ");
        return strHead + " " + strBody + " " + strTail;
    }

}
