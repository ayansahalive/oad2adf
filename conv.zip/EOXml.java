package conv;

import java.io.*;

import javax.xml.parsers.*;

import org.w3c.dom.*;


public class EOXml {
    public EOXml() {
        super();
    }

    protected static void handleEOXml(String path, String app, String dest, String repo) throws Exception {
        System.out.println("Start Conv: handleEOXml " + path + " " + app + " " + dest + " " + repo);
        String name = path.substring(path.lastIndexOf("\\") + 1);
        String topApp = dest + "\\" + app;
        String pathModel = topApp + "\\Model";
        String pathModelsrc = pathModel + "\\src\\model";

        createEOXml(pathModelsrc + "\\" + name, repo);

        File oafEO = new File(path); // OAF
        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        dbFactory.setValidating(false);
        DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
        Document oafDoc = dBuilder.parse(oafEO);
        Element EntityOaf = oafDoc.getDocumentElement();

        File adfEO = new File(pathModelsrc + "\\" + name);
        DocumentBuilderFactory newDbFactory = DocumentBuilderFactory.newInstance();
        newDbFactory.setValidating(false);
        DocumentBuilder newDBuilder = newDbFactory.newDocumentBuilder();
        Document adfDoc = newDBuilder.parse(adfEO);
        Element EntityAdf = adfDoc.getDocumentElement();

        // update Entity attributes for classes
        NamedNodeMap attrs = EntityOaf.getAttributes();
        for (int i = 0; i < attrs.getLength(); i++) {
            Node currentAtt = attrs.item(i);
            if (currentAtt.getNodeName().equals("CollClass") || currentAtt.getNodeName().equals("DefClass") ||
                currentAtt.getNodeName().equals("RowClass")) {
                String val = DirCreator.changedClassPath(currentAtt.getNodeValue());
                EntityAdf.setAttribute(currentAtt.getNodeName(), val);
            } else if (currentAtt.getNodeName().equals("Name") || currentAtt.getNodeName().equals("DBObjectType") ||
                       currentAtt.getNodeName().equals("DBObjectName") ||
                       currentAtt.getNodeName().equals("AliasName") ||
                       currentAtt.getNodeName().equals("BindingStyle")) {
                EntityAdf.setAttribute(currentAtt.getNodeName(), currentAtt.getNodeValue());
            }
        }


        // accessor and enrity attributes
        NodeList nodesOaf = EntityOaf.getChildNodes();
        for (int i = 0; i < nodesOaf.getLength(); i++) {
            Node currentNode = nodesOaf.item(i);
            if (currentNode.getNodeType() == Node.ELEMENT_NODE) {
                if (currentNode.getNodeName().equals("Attribute")) {
                    Node newNode = adfDoc.importNode(currentNode, true);
                    NamedNodeMap newAttrs = newNode.getAttributes();
                    for (int j = 0; j < newAttrs.getLength(); j++) {
                        Node subNode = newAttrs.item(i);
                        if (subNode.getNodeType() == Node.ELEMENT_NODE && subNode.getNodeName().equals("DesignTime")) {
                            newNode.removeChild(subNode); // DesignTime
                            System.out.println("***************************************************************** removed designtime");
                        }
                    }
                    EntityAdf.appendChild(newNode);
                } else if (currentNode.getNodeName().equals("AccessorAttribute")) {
                    Element newNode = (Element) adfDoc.importNode(currentNode, true);
                    NamedNodeMap Attrs = currentNode.getAttributes();
                    for (int j = 0; j < Attrs.getLength(); j++) {
                        Node subNode = Attrs.item(j);
                        if (subNode.getNodeName().equals("Association") ||
                            subNode.getNodeName().equals("AssociationEnd") ||
                            subNode.getNodeName().equals("AssociationOtherEnd")) {
                            String val = DirCreator.changedClassPath(subNode.getNodeValue());
                            newNode.setAttribute(subNode.getNodeName(), val);
                        }
                    }
                    EntityAdf.appendChild(newNode);
                } else if (currentNode.getNodeName().equals("Key")) {
                    Node newNode = adfDoc.importNode(currentNode, true);
                    EntityAdf.appendChild(newNode);
                } else if (currentNode.getNodeName().equals("DesignTime")) {
                    NodeList childList = currentNode.getChildNodes();
                    for (int x = 0; x < childList.getLength(); x++) {
                        Node child = childList.item(x); // attr
                        NamedNodeMap childAttrList = child.getAttributes();
                        if (null != childAttrList) {
                            for (int y = 0; y < childAttrList.getLength(); y++) {
                                Node childAttr = childAttrList.item(y); // name, value
                                if (childAttr.getNodeValue().contains("_codeGenFlag")) { // _codeGenFlag2
                                    // find and update design
                                    NodeList adfList = EntityAdf.getChildNodes();
                                    for (int z = 0; z < adfList.getLength(); z++) {
                                        Node designNode = adfList.item(z);
                                        if (designNode.getNodeName().equals("DesignTime")) {
                                            Node newNode = adfDoc.importNode(child, true);
                                            designNode.appendChild(newNode);
                                        }
                                    }
                                }
                            }
                        }

                    }
                }
            }
        }

        // jpx
        File jpx = new File(pathModelsrc + "\\Model.jpx");
        DocumentBuilderFactory fact = DocumentBuilderFactory.newInstance();
        fact.setValidating(false);
        DocumentBuilder db = fact.newDocumentBuilder();
        Document jpxDoc = db.parse(jpx);
        NodeList nextDesignList = jpxDoc.getElementsByTagName("Containee");
        Element Containee = (Element) nextDesignList.item(0);
        NodeList ContaineeChildren = Containee.getChildNodes();
        Node DesignTime = ContaineeChildren.item(1); // DesignTime element not handled as it requires translation
        int c = 0;
        NodeList children = DesignTime.getChildNodes();
        for (int k = 0; k < children.getLength(); k++) {
            Node child = children.item(k);
            if (child.getNodeType() == Node.ELEMENT_NODE) {
                NamedNodeMap childAttrs = child.getAttributes(); // Attr
                for (int z = 0; z < childAttrs.getLength(); z++) {
                    Node attr = childAttrs.item(z);
                    if ("Name".equals(attr.getNodeName()) && "_EO".equals(attr.getNodeValue())) {
                        c++;
                    }
                }
            }
        }
        if (c == 0) {
            Element newElement2 = jpxDoc.createElement("Attr");
            newElement2.setAttribute("Name", "_EO");
            newElement2.setAttribute("Value", "true");
            DesignTime.appendChild(newElement2);
        }

        FileReaderWritter.writeXMLFile(jpxDoc, pathModelsrc + "\\Model.jpx");

        FileReaderWritter.writeXMLFile(adfDoc, pathModelsrc + "\\" + name);

        System.out.println("End Conv: handleEOXml ");

    }

    /**
     * create empty xml
     * @param dest
     * @param repo
     * @throws Exception
     */
    private static void createEOXml(String dest, String repo) throws Exception {
        System.out.println("Start Conv: createEOXml " + dest + " " + repo);
        String contents =
            "<?xml version=\"1.0\" encoding=\"UTF-8\" ?>" + "<!DOCTYPE Entity SYSTEM \"jbo_03_01.dtd\">" + "<Entity" +
            "  xmlns=\"http://xmlns.oracle.com/bc4j\"" + "  Version=\"12.1.3.10.47\"" +
            "  InheritPersonalization=\"merge\" >  <DesignTime>" + "    <Attr Name=\"_isCodegen\" Value=\"true\"/>" +
            "  </DesignTime>  </Entity>";
        DirCreator.copyADFDTD(repo, dest);
        FileReaderWritter.writeFile(contents, dest);
        System.out.println("End Conv: createEOXml ");
    }

}
