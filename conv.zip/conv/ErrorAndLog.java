package conv;


public class ErrorAndLog {
    public ErrorAndLog() {
        super();
    }

    protected void handleErrors() {

    }

    protected void handleLog() {

    }
}
