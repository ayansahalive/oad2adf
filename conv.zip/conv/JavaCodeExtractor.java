package conv;

import java.util.*;

public class JavaCodeExtractor {
    public JavaCodeExtractor() {
        super();
    }

    private Vector vec = new Vector();

    public void setVec(Vector vec) {
        this.vec = vec;
    }

    public Vector getVec() {
        return vec;
    }

    /**
     * Copy conetents of a java file into elements of a vector by declaration and method signature
     * @param path
     * @return
     * @throws Exception
     */
    protected Vector start(String path) throws Exception {
        System.out.println("Start Conv: start " + path);
        String str = FileReaderWritter.getCharContents(path);
        str = str.replaceAll("\\s ", "");

        int classStart = str.indexOf("{");
        int classEnd = str.lastIndexOf("}");
        getVec().addElement(str.subSequence(0, classStart + 1));
        CharSequence data = str.subSequence(classStart + 1, classEnd);
        str = data.toString();
        this.segregator(str);
        getVec().addElement("}");
        System.out.println("End Conv: start ");
        return getVec();
    }

    private void segregator(String str) {
        int size = str.length();
        int head = 0;

        int startBraces = str.indexOf("{");
        int semicolon = str.indexOf(";");

        if (startBraces == -1 && semicolon != -1)
            startBraces = semicolon + 1;
        else if (semicolon == -1 && startBraces != -1)
            semicolon = startBraces + 1;

        if (semicolon < startBraces) {
            String declaration = str.subSequence(0, semicolon + 1).toString().trim();
            getVec().addElement(declaration);
            head = semicolon + 1;
            str = str.substring(head);
        } else if (semicolon > startBraces) {
            int counter = 1;
            int len = str.length();
            String closed = "";
            for (int i = 0; i < len; i++) {
                if (str.substring(i, i + 1).equals("{")) {
                    closed = "";
                    ++counter;
                } else if (str.substring(i, i + 1).equals("}")) {
                    closed = "yes";
                    --counter;
                }

                if (counter == 1 && closed.equals("yes")) {
                    String method = str.subSequence(head, i + 1).toString().trim();
                    getVec().addElement(method);
                    head = i + 1;
                    str = str.substring(head);
                    break;
                }
            }
        } else {
            return;
        }

        if (head < size && str != null)
            segregator(str);
    }
}
