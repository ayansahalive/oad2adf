package conv;

import java.util.*;


public class AMImpl {
    public AMImpl() {
        super();
    }

    /**
     * Generate and write AMImpl file
     * @param path
     * @param app
     * @param dest
     */
    protected static void handleAMImpl(String path, String app, String dest) throws Exception {
        System.out.println("Start Conv: handleAMImpl " + path + " " + app + " " + dest);
        try {
            String name = path.substring(path.lastIndexOf("\\") + 1);
            JavaCodeExtractor obj = new JavaCodeExtractor();
            Vector vec = obj.start(path);
            String str = "";

            // remove main
            for (int i = 0; i < vec.size(); i++) {
                String contents = vec.get(i) + "";
                if (contents.contains("void main"))
                    continue;
                str = str + "\n" + vec.get(i) + "";
            }

            // replace import
            str =
                str.replace("import oracle.apps.fnd.framework.server.OAApplicationModuleImpl;",
                            "import oracle.jbo.server.ApplicationModuleImpl;");

            // replace extends
            str = str.replace("OAApplicationModuleImpl", "ApplicationModuleImpl");

            // replace package
            String pkg = str.substring(0, str.indexOf(";"));
            str = str.replace(pkg, "package model");

            // replace Number
            str = str.replace(" Number", "oracle.jbo.domain.Number");

            // write a new file
            String destination = dest + "\\" + app + "\\Model\\src\\model\\" + name;
            FileReaderWritter.writeFile(str, destination);

            System.out.println("End Conv: handleAMImpl");
        } catch (Exception e) {
            throw e;
        }

    }

    protected static void handleAMDefImpl(String path, String app, String dest) throws Exception {
        System.out.println("Start Conv: handleAMDefImpl " + path + " " + app + " " + dest);

        try {
            String name = path.substring(path.lastIndexOf("\\") + 1);
            JavaCodeExtractor obj = new JavaCodeExtractor();
            Vector vec = obj.start(path);
            String str = "";

            // remove main
            for (int i = 0; i < vec.size(); i++) {
                String contents = vec.get(i) + "";
                if (contents.contains("void main"))
                    continue;
                str = str + "\n" + vec.get(i) + "";
            }


            // replace package
            String pkg = str.substring(0, str.indexOf(";"));
            str = str.replace(pkg, "package model");

            // write a new file
            String destination = dest + "\\" + app + "\\Model\\src\\model\\" + name;
            FileReaderWritter.writeFile(str, destination);

            System.out.println("End Conv: handleAMDefImpl");
        } catch (Exception e) {
            throw e;
        }
    }
}
