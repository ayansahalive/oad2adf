package conv;

import java.io.*;

import java.util.zip.*;

public class DirCreator {
    public DirCreator() {
        super();
    }

    private static final int BUFFER_SIZE = 4096;

    /**
     * Generate Destination directories
     * @param app
     * @param dest
     * @param repo
     */
    protected static void createDir(String app, String dest, String repo) throws Exception {
        System.out.println("Start Conv: createDir " + app + " " + dest + " " + repo);
        String path = dest + "\\" + app;
        File newFolder = new File(path);
        newFolder.mkdirs();

        // Model
        String pathModel = path + "\\Model";
        newFolder = new File(pathModel);
        newFolder.mkdirs();
        String pathModelsrc = pathModel + "\\src\\model";
        newFolder = new File(pathModelsrc);
        newFolder.mkdirs();
        String pathModelCom = pathModelsrc + "\\common";
        newFolder = new File(pathModelCom);
        newFolder.mkdirs();

        // src
        String pathSrc = path + "\\src\\META-INF";
        newFolder = new File(pathSrc);
        newFolder.mkdirs();


        // ViewController
        String pathVC = path + "\\ViewController";
        newFolder = new File(pathVC);
        newFolder.mkdirs();
        String pathVCsrc = pathVC + "\\src\\view\\backing";
        newFolder = new File(pathVCsrc);
        newFolder.mkdirs();
        pathVCsrc = pathVC + "\\src\\META-INF";
        newFolder = new File(pathVCsrc);
        newFolder.mkdirs();
        String pathVCpub = pathVC + "\\public_html\\WEB-INF";
        newFolder = new File(pathVCpub);
        newFolder.mkdirs();
        String pathVCmodel = pathVC + "\\model\\WEB-INF";
        newFolder = new File(pathVCmodel);
        newFolder.mkdirs();
        String pathVCadf = pathVC + "\\adfmsrc\\view\\pageDefs";
        newFolder = new File(pathVCadf);
        newFolder.mkdirs();
        pathVCadf = pathVC + "\\adfmsrc\\META-INF";
        newFolder = new File(pathVCadf);
        newFolder.mkdirs();

        // copy src
        copySrcFiles(repo, app, pathSrc);

        //copy VC
        copyVCFiles(pathVC, repo, app);

        // copy project
        copyProjectFiles(dest, app, repo);

        System.out.println("End Conv: createDir");
    }

    /**
     * copy project related files for jdeveloper
     * @param dest
     * @param app
     * @param repo
     * @throws Exception
     */
    private static void copyProjectFiles(String dest, String app, String repo) throws Exception {
        System.out.println("Start Conv: copyProjectFiles " + dest + " " + app + " " + repo);

        String pathModel = dest + "\\" + app + "\\Model";
        String pathVC = dest + "\\" + app + "\\ViewController";
        String pathJWS = dest + "\\" + app;

        String Mjpr = FileReaderWritter.getCharContents(repo + "\\testApp\\Model\\Model.jpr");
        Mjpr = Mjpr.replace("testApp", app);
        FileReaderWritter.writeFile(Mjpr, pathModel + "\\Model.jpr");

        String VCjpr = FileReaderWritter.getCharContents(repo + "\\testApp\\ViewController\\ViewController.jpr");
        VCjpr = VCjpr.replace("testApp", app);
        FileReaderWritter.writeFile(VCjpr, pathVC + "\\ViewController.jpr");

        String jws = FileReaderWritter.getCharContents(repo + "\\testApp\\testApp.jws");
        jws = jws.replace("testApp", app);
        FileReaderWritter.writeFile(jws, pathJWS + "\\" + app + ".jws");

        String jpx = FileReaderWritter.getCharContents(repo + "\\testApp\\Model\\src\\model\\Model.jpx");
        FileReaderWritter.writeFile(jpx, pathModel + "\\src\\model\\Model.jpx");

        String bc4j = FileReaderWritter.getCharContents(repo + "\\testApp\\Model\\src\\model\\common\\bc4j.xcfg");
        FileReaderWritter.writeFile(bc4j, pathModel + "\\src\\model\\common\\bc4j.xcfg");

        System.out.println("End Conv: copyProjectFiles");
    }

    /**
     *  Copy DTD to OAF fioldes before parsing
     * @param repo
     * @param dest
     */
    protected static void copyOAFDTD(String repo, String dest) throws Exception {
        dest = dest.substring(0, dest.lastIndexOf("\\"));
        System.out.println("Start Conv: copyDTD " + repo + " " + dest);
        FileReaderWritter.copyFile(repo + "\\jbo_03_01_oaf.dtd", dest + "\\jbo_03_01.dtd");
        System.out.println("End Conv: copyDTD");
    }

    protected static void copyADFDTD(String repo, String dest) throws Exception {
        dest = dest.substring(0, dest.lastIndexOf("\\"));
        System.out.println("Start Conv: copyDTD " + repo + " " + dest);
        FileReaderWritter.copyFile(repo + "\\jbo_03_01_adf.dtd", dest + "\\jbo_03_01.dtd");
        System.out.println("End Conv: copyDTD");
    }

    /**
     *  Copy standard src files
     * @param repo
     * @param app
     * @param pathSrc
     */
    private static void copySrcFiles(String repo, String app, String pathSrc) throws Exception {
        System.out.println("Start Conv: copySrcFiles " + repo + " " + app + " " + pathSrc);

        String jps = repo + "\\testApp\\src\\META-INF\\jps-config.xml";
        String webapp = repo + "\\testApp\\src\\META-INF\\weblogic-application.xml";

        jps = FileReaderWritter.getCharContents(jps);
        jps = jps.replace("testApp", app);
        webapp = FileReaderWritter.getCharContents(webapp);

        FileReaderWritter.writeFile(jps, pathSrc + "\\jps-config.xml");
        FileReaderWritter.writeFile(webapp, pathSrc + "\\weblogic-application.xml");
        FileReaderWritter.copyFile(repo + "\\testApp\\src\\META-INF\\cwallet.sso", pathSrc + "\\cwallet.sso");

        System.out.println("End Conv: copySrcFiles");
    }

    /**
     * Copy standard ViewController project files
     * @param pathVC
     * @param src
     * @param app
     */
    private static void copyVCFiles(String pathVC, String repo, String app) throws Exception {
        System.out.println("Start Conv: copyVCFiles " + pathVC + " " + repo + " " + app);

        FileReaderWritter.copyFile(repo + "\\testApp\\ViewController\\public_html\\WEB-INF\\faces-config.xml",
                                   pathVC + "\\public_html\\WEB-INF\\faces-config.xml");
        FileReaderWritter.copyFile(repo + "\\testApp\\ViewController\\public_html\\WEB-INF\\trinidad-config.xml",
                                   pathVC + "\\public_html\\WEB-INF\\trinidad-config.xml");
        FileReaderWritter.copyFile(repo + "\\testApp\\ViewController\\public_html\\WEB-INF\\web.xml",
                                   pathVC + "\\public_html\\WEB-INF\\web.xml");
        FileReaderWritter.copyFile(repo + "\\testApp\\ViewController\\src\\META-INF\\adf-settings.xml",
                                   pathVC + "\\src\\META-INF\\adf-settings.xml");
        FileReaderWritter.copyFile(repo + "\\testApp\\ViewController\\public_html\\WEB-INF\\adfc-config.xml",
                                   pathVC + "\\public_html\\WEB-INF\\adfc-config.xml");
        FileReaderWritter.copyFile(repo + "\\testApp\\ViewController\\adfmsrc\\view\\DataBindings.cpx",
                                   pathVC + "\\adfmsrc\\view\\DataBindings.cpx");

        System.out.println("End Conv: copyVCFiles");
    }

    /**
     * Unizp app
     * @param zipFilePath
     * @param destDirectory
     * @return
     */
    protected static String unzip(String zipFilePath, String destDirectory) throws Exception {
        System.out.println("Start Conv: unzip " + zipFilePath + " " + destDirectory);
        try {
            File destDir = new File(destDirectory);
            if (!destDir.exists()) {
                destDir.mkdir();
            }
            ZipInputStream zipIn = new ZipInputStream(new FileInputStream(zipFilePath));
            ZipEntry entry = zipIn.getNextEntry();
            // iterates over entries in the zip file
            while (entry != null) {
                String filePath = destDirectory + File.separator + entry.getName();
                if (!entry.isDirectory()) {
                    // if the entry is a file, extracts it
                    extractFile(zipIn, filePath);
                } else {
                    // if the entry is a directory, make the directory
                    File dir = new File(filePath);
                    dir.mkdir();
                }
                zipIn.closeEntry();
                entry = zipIn.getNextEntry();
            }
            zipIn.close();
            System.out.println("End Conv: unzip ");
            return "success";
        } catch (Exception e) {
            throw e;
        }
    }

    /**
     * Loop through zipped folders
     * @param zipIn
     * @param filePath
     * @throws IOException
     */
    protected static void extractFile(ZipInputStream zipIn, String filePath) throws Exception {
        System.out.println("Start Conv: extractFile " + filePath);
        BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(filePath));
        byte[] bytesIn = new byte[BUFFER_SIZE];
        int read = 0;
        while ((read = zipIn.read(bytesIn)) != -1) {
            bos.write(bytesIn, 0, read);
        }
        bos.close();
        System.out.println("End Conv: extractFile ");
    }

    /**
     * return the changed path from oaf to adf
     * @param path
     * @return
     */
    protected static String changedClassPath(String path) {
        System.out.println("Start Conv: changedClassPath " + path);
        path = path.substring(path.lastIndexOf("."));
        String retPath = "model" + path;
        //        String retPath = "model." + path;
        System.out.println("End Conv: changedClassPath");
        return retPath;
    }

    /**
     * changed class paths for VL and AO
     * @param path
     * @return
     */
    protected static String changedVLAOClassPath(String path) {
        System.out.println("Start Conv: changedVLAOClassPath " + path);
        String ret = "";
        String col = path.substring(0, path.lastIndexOf("."));
        String vo = col.substring(0, col.lastIndexOf("."));
        path = path.replace(vo, "");
        ret = "model" + path;
        System.out.println("End Conv: changedVLAOClassPath");
        return ret;
    }
}
