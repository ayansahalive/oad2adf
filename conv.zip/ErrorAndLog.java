package conv;

import java.io.*;


public class ErrorAndLog {
    public ErrorAndLog() {
        super();
    }

    protected static void handleErrors(String app, String contents) {
        System.out.println("Start Conv: handleErrors " + app + " " + contents);
        try {
            String dest = System.getenv("ADF_DESTINATION") + FileReaderWritter.getSeparator() + app + "Errors.txt";
            File f = new File(dest);
            if (!f.exists()) {
                FileReaderWritter.writeFile("Errors for OAF to ADF Conversion of " + app + "\n", dest);
                FileReaderWritter.appendFile(contents, dest);
            } else
                FileReaderWritter.appendFile(contents, dest);
            System.out.println("End Conv: handleErrors ");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    protected static void handleLog(String app, String contents) {
        System.out.println("Start Conv: handleLog " + app + " " + contents);
        try {
            String dest = System.getenv("ADF_DESTINATION") + FileReaderWritter.getSeparator() + app + "Log.txt";
            File f = new File(dest);
            if (!f.exists()) {
                FileReaderWritter.writeFile("Starting OAF to ADF Conversion of " + app + "\n", dest);
                FileReaderWritter.appendFile(contents, dest);
            } else
                FileReaderWritter.appendFile(contents, dest);
            System.out.println("End Conv: handleLog ");
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
