package conv;

public class TFGen {
    public TFGen() {
        super();
    }
}
